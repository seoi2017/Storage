#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>

#define EVAL_OUTPUT_FILE "/tmp/_eval.score"

FILE *fpout, *fpans, *fpeval, *fpin;
/* Output message and exit */
void output (char *s, int d)
{
	if (fpeval) {
		fprintf (fpeval, "%s\n%d\n", s, d);
		fclose (fpeval);
	}
	exit(d != 0);
}

/* Open files and check */
void open_files(char *in, char *out, char *ans)
{
	if ((fpeval = fopen (EVAL_OUTPUT_FILE, "w")) == NULL) {
		fprintf (stderr, "Can not open %s!\n", EVAL_OUTPUT_FILE);
		output ("Can not open eval record file!", 0);
	}
	
	if ((fpin = fopen (in, "r")) == NULL) {
		fprintf (stderr, "Can not open %s!\n", in);
		output ("Can not open standard input file!", 0);
	}

	if ((fpout = fopen (out, "r")) == NULL) {
		fprintf (stderr, "Can not open %s!\n", out);
		output ("Can not open player's output file!", 0);
	}

	if ((fpans = fopen (ans, "r")) == NULL) {
		fprintf (stderr, "Can not open %s!\n", ans);
		output ("Can not open standard answer!", 0);
	}
}

char s1[100],s2[100],s3[100];
int main (int argc, char *argv[])
{
	char c1, c2;
		
	if (argc != 4) {
		fprintf (stderr, "Usage: mason_e <in> <out> <ans>\n");
		output ("Invalid Call!", 0);
	}
	
	open_files (argv[1], argv[2], argv[3]);
	
	/* Compare the contens */
	
	int n;
	bool fl=true;
	fscanf(fpin,"%d",&n);
	for (int i=1;i<=n;++i){
		fscanf(fpout,"%s",s3);
		fscanf(fpans,"%s%s",s1,s2);
		if (strcmp(s1,s3)==0) continue;
		else if (strcmp(s2,s3)==0) fl=false;
		else output("Wrong answer.",0);
	}
	if (fl) output("Accept.",10);
	else output("Subtask finished.", 4);
	return 0;
}