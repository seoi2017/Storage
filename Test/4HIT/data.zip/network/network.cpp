#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int mod=1000000007;
const int maxn=300100;

int to[maxn],n;
long long dp[maxn];
long long check[maxn];
long double check2[maxn];
long double f[maxn];
int trs[maxn];
long double ts[maxn];
bool vis[maxn];
int q[maxn],t,h;
int id[maxn],tot;
int in[maxn];

long long power(long long a,int b){
	long long ret=1;
	while(b){
		if (b&1) ret=ret*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return ret;
}

inline void solve(){
	long double a=ts[id[tot]],b=f[id[1]];
	long long tmpa=trs[id[tot]],tmpb=dp[id[1]];
	for (int i=tot-1;i>=1;--i){
		b+=f[id[i+1]]*a;
		a*=ts[id[i]];
		(tmpb+=dp[id[i+1]]*tmpa)%=mod;
		tmpa=tmpa*trs[id[i]]%mod;
		// printf("i=%d,a=%lf,b=%lf\n",id[i],(double)a,(double)b);
	}
	dp[id[1]]=tmpb*power(1-tmpa+mod,mod-2)%mod;
	f[id[1]]=b/(1-a);
	for (int i=1;i<tot;++i){
		(dp[id[i+1]]+=dp[id[i]]*trs[id[i]]%mod)%=mod;
		f[id[i+1]]+=f[id[i]]*ts[id[i]];
	}
	return;
}

// #define maker

int main(){
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;++i){
		scanf("%d",&to[i]);
		++in[to[i]];
	}
	int a,b;
	for (int i=1;i<=n;++i){
		scanf("%d%d",&a,&b);
		trs[i]=a*power(b,mod-2)%mod;
		ts[i]=(double)a/b;
	}
	for (int i=1;i<=n;++i){
		scanf("%lld",&dp[i]);
		check2[i]=f[i]=check[i]=dp[i];
	}
	for (int i=1;i<=n;++i) if (in[i]==0) q[t++]=i;
	while(h<t){
		int p=q[h++];
		vis[p]=true;
		(dp[to[p]]+=trs[p]*dp[p])%=mod;
		f[to[p]]+=f[p]*ts[p];
		if (--in[to[p]]==0) q[t++]=to[p];
	}
	for (int i=1;i<=n;++i) if (!vis[i]){
		tot=0;
		int p=to[i];
		vis[i]=true;
		id[++tot]=i;
		while(p!=i){
			id[++tot]=p;
			vis[p]=true;
			p=to[p];
		}
		solve();
	}
	for (int i=1;i<=n;++i){
		(check[to[i]]+=dp[i]*trs[i])%=mod;
		check2[to[i]]+=f[i]*ts[i];
	}
	for (int i=1;i<=n;++i) if (fabs(f[i]-check2[i])>1e-6||check[i]!=dp[i]){
		fprintf(stderr,"WA!!!!!!!!");
		while(1);
	}
	#ifdef maker
	for (int i=1;i<=n;++i) printf("%lld %.3lf\n",dp[i],(double)f[i]);
	#else
	for (int i=1;i<=n;++i) printf("%lld ",dp[i]);
	#endif
	return 0;
}
